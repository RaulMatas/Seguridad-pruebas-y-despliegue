const { Sequelize } = require('sequelize');

// Instancia de Sequelize
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './db.sqlite'
});

// Exportar sequelize y la instancia para usar en otros archivos
module.exports = {
  sequelize,
  Sequelize
};
