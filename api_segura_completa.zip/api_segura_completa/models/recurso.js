const { DataTypes } = require('sequelize');
const { sequelize } = require('./index');

const Recurso = sequelize.define('Recurso', {
  nombre: {
    type: DataTypes.STRING,
    allowNull: false
  },
  descripcion: {
    type: DataTypes.TEXT
  },
  fecha: {
    type: DataTypes.DATE,
    allowNull: false
  }
});

module.exports = Recurso;
