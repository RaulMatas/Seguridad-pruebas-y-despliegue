const { sequelize } = require('./index');
const User = require('./user');
const Recurso = require('./recurso');

module.exports = {
  sequelize,
  User,
  Recurso
};
