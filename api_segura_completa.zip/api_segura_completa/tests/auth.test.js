const request = require('supertest');
const app = require('../index');

describe('Auth Endpoints', () => {
  it('should register a user', async () => {
    const res = await request(app).post('/register').send({
      email: 'test@example.com',
      password: '123456'
    });
    expect(res.statusCode).toEqual(201);
  });

  it('should login and return JWT', async () => {
    const res = await request(app).post('/login').send({
      email: 'test@example.com',
      password: '123456'
    });
    expect(res.body).toHaveProperty('token');
  });
});
