const Recurso = require('../models/recurso');
const redisClient = require('../middlewares/cache');

const TTL = 60 * 10; // 10 minutos

exports.getAll = async (req, res) => {
  const cacheKey = 'recursos:all';
  try {
    const cached = await redisClient.get(cacheKey);
    if (cached) {
      console.log('Respuesta desde Redis');
      return res.json(JSON.parse(cached));
    }

    const recursos = await Recurso.findAll();
    await redisClient.setEx(cacheKey, TTL, JSON.stringify(recursos));
    console.log('Guardado en Redis');

    res.json(recursos);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener recursos' });
  }
};

exports.getById = async (req, res) => {
  const id = req.params.id;
  const cacheKey = `recursos:${id}`;
  try {
    const cached = await redisClient.get(cacheKey);
    if (cached) {
      console.log(`Recurso ${id} desde Redis`);
      return res.json(JSON.parse(cached));
    }

    const recurso = await Recurso.findByPk(id);
    if (!recurso) return res.status(404).json({ error: 'No encontrado' });

    await redisClient.setEx(cacheKey, TTL, JSON.stringify(recurso));
    res.json(recurso);
  } catch (error) {
    res.status(500).json({ error: 'Error interno' });
  }
};

exports.create = async (req, res) => {
  const { nombre, descripcion, fecha } = req.body;
  try {
    const nuevo = await Recurso.create({ nombre, descripcion, fecha });
    await redisClient.del('recursos:all');
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear recurso' });
  }
};

exports.update = async (req, res) => {
  const id = req.params.id;
  const { nombre, descripcion, fecha } = req.body;
  try {
    const recurso = await Recurso.findByPk(id);
    if (!recurso) return res.status(404).json({ error: 'No encontrado' });

    recurso.nombre = nombre;
    recurso.descripcion = descripcion;
    recurso.fecha = fecha;
    await recurso.save();

    await redisClient.del('recursos:all');
    await redisClient.del(`recursos:${id}`);
    res.json(recurso);
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar recurso' });
  }
};

exports.remove = async (req, res) => {
  const id = req.params.id;
  try {
    const recurso = await Recurso.findByPk(id);
    if (!recurso) return res.status(404).json({ error: 'No encontrado' });

    await recurso.destroy();
    await redisClient.del('recursos:all');
    await redisClient.del(`recursos:${id}`);
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar recurso' });
  }
};
