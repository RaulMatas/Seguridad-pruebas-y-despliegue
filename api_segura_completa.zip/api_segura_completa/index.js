require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const { sequelize } = require('./models/loadModels');
const recursoRoutes = require('./routes/recursoRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware global
app.use(helmet());
app.use(express.json());

// Rutas principales
app.use('/recursos', recursoRoutes);
app.use(authRoutes); // Maneja /login y /register

// Ruta de prueba
app.get('/', (req, res) => {
  res.send('API segura funcionando');
});

// Iniciar el servidor
sequelize.sync().then(() => {
  app.listen(PORT, () => {
    console.log(`Servidor iniciado en http://localhost:${PORT}`);
  });
}).catch((err) => {
  console.error('Error al conectar con la base de datos:', err);
});
