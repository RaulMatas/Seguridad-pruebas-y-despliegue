const redis = require('redis');

const redisClient = redis.createClient({
  url: 'redis://localhost:6379'
});

redisClient.connect()
  .then(() => console.log('🔌 Conectado a Redis'))
  .catch((err) => console.error('❌ Error conectando a Redis:', err));

module.exports = redisClient;
