const helmet = require('helmet');
const { body, validationResult } = require('express-validator');

const security = [
  helmet(),
  body('email').isEmail().normalizeEmail(),
  body('password').isString().trim().escape(),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

module.exports = security;
