# API Segura con Node.js, Sequelize, JWT y Redis

Este proyecto es una API RESTful construida con Node.js que incluye autenticación segura con JWT, almacenamiento de contraseñas con bcrypt, gestión de datos con Sequelize y SQLite, y caché de respuestas con Redis.

---

## Tecnologías utilizadas

- Node.js + Express
- SQLite + Sequelize ORM
- JWT (JSON Web Token)
- Redis (caché)
- bcrypt (hash de contraseñas)
- dotenv, helmet, express-validator
- Docker + Docker Compose

---

## Instalación local

### 1. Clonar el repositorio

```bash
git clone https://github.com/RaulMatas/API-Segura-Con-JWT-Redis.git
cd API-Segura-Con-JWT-Redis
