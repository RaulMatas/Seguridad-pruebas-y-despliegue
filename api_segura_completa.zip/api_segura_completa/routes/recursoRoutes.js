const express = require('express');
const router = express.Router();
const recursoController = require('../controllers/recursoController');
const authMiddleware = require('../middlewares/authMiddleware');

// Rutas públicas
router.get('/', recursoController.getAll);
router.get('/:id', recursoController.getById);

// Rutas protegidas
router.post('/', authMiddleware, recursoController.create);
router.put('/:id', authMiddleware, recursoController.update);
router.delete('/:id', authMiddleware, recursoController.remove);

module.exports = router;
